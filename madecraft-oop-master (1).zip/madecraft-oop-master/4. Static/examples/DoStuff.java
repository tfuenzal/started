package examples;

public class DoStuff {
	
	public static void main(String args[]) {
		new Pug().bark();
	}

}
