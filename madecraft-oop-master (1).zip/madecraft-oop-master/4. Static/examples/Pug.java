package examples;

public class Pug {
	
	void bark() {
		System.out.println("woof woof");
	}
}
