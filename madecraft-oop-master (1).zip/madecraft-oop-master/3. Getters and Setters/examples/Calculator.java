package examples;

public class Calculator {

	public static int add(int i, int j) {
		return i / j;
	}

}
