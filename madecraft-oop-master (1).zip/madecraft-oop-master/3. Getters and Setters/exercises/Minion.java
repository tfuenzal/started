package exercises;

public class Minion {

}
